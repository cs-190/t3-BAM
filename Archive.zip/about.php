<?php
	$current_page = "about";
	require_once("header.php");
?>