<?php
	$current_page = "contact";
	require_once("header.php");
?>