<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$current_page = "index";
require_once("header.php");
?>

<a href="#">
<div id="allclothes">
     <p class="allclothestext">
      All Clothes
      </p>
</div>

</a>
<a href="#">

<div id="costumes">
     <p class="categorytext">
     Costumes
      </p>
</div>
</a>

<a href="#">

<div id="formal">
     <p class="categorytext">
      Formal
     </p>
</div>

</a>


</body>